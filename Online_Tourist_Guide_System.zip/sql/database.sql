
CREATE DATABASE tourist_db;
USE tourist_db;

CREATE TABLE users(
id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(50),
email VARCHAR(50),
password VARCHAR(50)
);
